# XEFI TASK est une application mobile permettant aux utilisateurs de créer des taches à réaliser.


Cahier des charges FRONT: 

- Le développeur devra se fier au screen pour développer l'application
- L'utilisateur pourra créer une tâche avec un FloatingActionButton en bas a droite de l'écran
- Récupérer les taches déja existante de la base de données. Pour ça vous utiliserai l'API développé par le BACK
    qui vous enverra un JSON avec les données des taches existante
- une tâche devra comporter un titre, une description, une date, une couleur
- Une tache pourra avoir un statut, les différents statuts : Important, medium, Insignifiante, terminé
- Le code couleur sera le suivant, Rouge : Important, Orange : Peu important, Bleu: Pas important et vert : Terminé
- Au clique long sur une tache: Modification de la Card (Bleu sur le screen), 
    Pour valider ou annuler les modifications  : une icône valider et une icône annuler en bas à droite de la card 
    Suppression d'une tache au clique sur la poubelle en haut a droite de la CARD
- Quand la modification est valider vous devrez envoyer les données en format JSON à l'API
- Pour valider une tache et la passer en terminer : icône valider en bas à droite de la card (Orange sur le screen)
- A la validation d'une tache, vous changerai le status de la tache en terminé
- Possibilité d'étendre la tache pour voir la description au clique sur l'icone flèche vers le bas en bas a droite de la card (Orange sur le screen)
- Possibilité de filtrer (avec order) la liste des taches par date (de la plus proche a la plus lointaine) ou par Status (de la plus importante a la moins importante) 




