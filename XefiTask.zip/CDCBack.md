# XEFI TASK est une application mobile permettant aux utilisateurs de créer des taches à réaliser.


Cahier des charges BACK:

- Une base de données doit être créé et comprendra une table tâche avec les colonnes : title, description, status, end_date
- Une tache pourra avoir un statut, les différents statuts : Important, medium, Insignifiante, terminé
- Une API qui permettra la modification de la table Tache qui contiendra différente route : 
    - Une route update de tache qui modifiera une tache selon son ID
    - Une route index de tache qui récupérera toutes les tâches disponibles
    - Une route create qui permettra la création d'une tache
    - Une route validation qui changera le status d'une tache en validé selon son ID
    - Une route delete qui supprimera une tache selon son ID 